package CharacterMaking;

public interface Weapon {

	public int weaponDamage();
	
}
