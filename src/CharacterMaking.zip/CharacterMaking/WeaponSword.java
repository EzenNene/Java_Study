package CharacterMaking;

public class WeaponSword implements Weapon{

	@Override
	public int weaponDamage() {
		return 250;
	}

}
